from django.apps import AppConfig


class PhotowallConfig(AppConfig):
    name = 'photowall'
